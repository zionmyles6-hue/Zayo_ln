ZAYO LN PERSONAL COMMAND CENTRE

FILES
- index.html: the complete single-file website.

RUN IT
1. Open index.html in Chrome, Edge, Firefox or another modern browser.
2. Use the navigation to open Glow-up basics, IT & study, Money skills, Rugby lab and the other sections.
3. Your changes save in the browser on that device. Use Export backup regularly.

PUBLISH WITH GITHUB PAGES
1. Create a new GitHub repository named zayo-ln.
2. Set it to Public (or use a plan that supports Pages for private repositories).
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait for GitHub Pages to publish the site. The URL will be shown on the Pages settings screen.

IMPORTANT
This is a browser-local personal dashboard. Data is stored on the device/browser where you use it. It does not automatically sync between your phone and laptop. Export a JSON backup on one device and import it on another when needed. Do not store passwords or sensitive information in the journal.
